package api;

/**
 * Exception for when the API attempted to create a user and did not succeed.
 */
public class CreateUserException extends Exception {

}

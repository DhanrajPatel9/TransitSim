package api;

/**
 * Exception for when the API attempted to log a user in and failed.
 */
public class LoginFailedException extends Exception {

}

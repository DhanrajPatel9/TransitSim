package api;

/**
 * Exception for when the API attempted to update a user and failed.
 */
public class UpdateUserException extends Exception {

}

package api;

/**
 * Exception for when the API attempted to tap a card at a station and failed.
 */
public class TapFailedException extends Exception {

}

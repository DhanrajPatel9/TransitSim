package ui;

/**
 * Abstract class prompt title screen.
 */
public class TitleScreenController extends UiController {

}

package transit;

/**
 * Exception thrown to indicate when a user entered is not entered into the database.
 */
public class UserNotFoundException extends Exception {

}

package transit;/* Danya */

/**
 * Exception class to indicate when a deactivated card has attempted to tap.
 */
public class TapDeactivatedCardsException extends Exception {

}



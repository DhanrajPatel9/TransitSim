package util;

import java.io.IOException;

public class DataReadException extends IOException {

}

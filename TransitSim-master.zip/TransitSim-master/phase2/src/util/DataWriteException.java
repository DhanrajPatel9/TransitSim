package util;

import java.io.IOException;

public class DataWriteException extends IOException {

}
